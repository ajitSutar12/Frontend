import { ButtonDirective } from './button.directive';

describe('ButtonDirective', () => {
  it('should create an instance', () => {
    const directive = new ButtonDirective();
    expect(directive).toBeTruthy();
  });
});
