import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hot-keys',
  templateUrl: './hot-keys.component.html',
  styleUrls: ['./hot-keys.component.scss']
})
export class HotKeysComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
