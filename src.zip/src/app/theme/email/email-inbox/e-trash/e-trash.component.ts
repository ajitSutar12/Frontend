import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-e-trash',
  templateUrl: './e-trash.component.html',
  styleUrls: [
    './e-trash.component.scss'
  ]
})
export class ETrashComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
