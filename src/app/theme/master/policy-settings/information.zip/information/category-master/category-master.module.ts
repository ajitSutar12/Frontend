import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {CategoryMasterService} from './category-master.service'

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers:[CategoryMasterService]
})
export class CategoryMasterModule { }
