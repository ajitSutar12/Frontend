import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";

import { DataTablesModule } from "angular-datatables";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { ColorPickerModule } from "ngx-color-picker";

import { SecurityDetailsComponent } from "./security-details.component";
import { SecurityDetailsRoutingModule } from "./securityDetails-routing.module";

import { OwnDepositsComponent } from "./own-deposits/own-deposits.component";
import { OtherSecurityComponent } from "./other-security/other-security.component";
import { FirePolicyComponent } from "./fire-policy/fire-policy.component";
import { MarketSharesComponent } from "./market-shares/market-shares.component";
import { StockStatementComponent } from "./stock-statement/stock-statement.component";
import { GovtSecurityAndLicComponent } from "./govt-security-and-lic/govt-security-and-lic.component";
import { PlantAndMachineryComponent } from "./plant-and-machinery/plant-and-machinery.component";
import { FurnitureAndFixtureComponent } from "./furniture-and-fixture/furniture-and-fixture.component";
import { VehicleComponent } from "./vehicle/vehicle.component";
import { LandAndBuildingsComponent } from "./land-and-buildings/land-and-buildings.component";
import { GoldAndSilverComponent } from "./gold-and-silver/gold-and-silver.component";

import { CustomerInsuranceComponent } from "./customer-insurance/customer-insurance.component";
import { BookDebtsComponent } from "./book-debts/book-debts.component";
import { PleadgeStockComponent } from "./pleadge-stock/pleadge-stock.component";

import { PerfectScrollbarModule } from "ngx-perfect-scrollbar";
import { PERFECT_SCROLLBAR_CONFIG } from "ngx-perfect-scrollbar";
import { PerfectScrollbarConfigInterface } from "ngx-perfect-scrollbar";
import { SelectModule } from "ng-select";
import { OtherSecurity2Component } from "./other-security2/other-security2.component";
import { glMasterService } from "../../../../shared/elements/gl-master.service";
import { GoldsilverService } from "../../../../shared/dropdownService/goldsilver.service";
import { InsuranceService } from "../../../../shared/elements/insurance.service";
import { Ac1Service } from "../../../../shared/elements/ac1.service";
import { S1Service } from "../../../../shared/elements/s1.service";
import { Ac2Service } from "../../../../shared/elements/ac2.service";
import { S2Service } from "../../../../shared/elements/s2.service";
import { OwnDepositsComponentService } from "./own-deposits/own-deposits.component.service";
import { othersecuritycomponentservice } from "./other-security/other-security.component.service";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { firepolicycomponentservice } from "./fire-policy/fire-policy.component.service";
import { OwnbranchMasterService } from "../../../../shared/dropdownService/own-branch-master-dropdown.service";
import { schemedropdownService } from "../../../../shared/dropdownService/scheme-dropdown.service";
import { marketsharesomponentservice } from "../security-details/market-shares/market-shares.component.service";
import { stockcomponentservice } from "../security-details/stock-statement/stock-statement.component.service";
import { governmentsecuritycomponentservice } from "../security-details/govt-security-and-lic/govt-security-and-lic.component.service";
import { plantmachineryService } from "../security-details/plant-and-machinery/plant-and-machinery.service";
import { furnitureandfixtureservice } from "../security-details/furniture-and-fixture/furniture-and-fixture.service";
import { VehicleService } from "./vehicle/vehicle.service";
import { landandbuildingsService } from "./land-and-buildings/land-and-buildings.service";
import { goldandsilverService } from "./gold-and-silver/gold-and-silver.service";
import{customerinsuranceService} from './customer-insurance/customer-insurance.service'
import{InsuranceMasterDropdownService} from '../../../../shared/dropdownService/insurance-master-dropdown.service'
import{BookdebtsService } from './book-debts/book-debts.service'
import{pleadgestockService} from './pleadge-stock/pleadge-stock.service'
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true,
};

@NgModule({
  imports: [
    CommonModule,
    DataTablesModule,
    SecurityDetailsRoutingModule,
    NgbModule,
    ColorPickerModule,
    SelectModule,
    PerfectScrollbarModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [
    GoldsilverService,
    InsuranceService,
    Ac1Service,
    S1Service,
    Ac2Service,
    S2Service,
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG,
    },
    glMasterService,
    OwnDepositsComponent,
    othersecuritycomponentservice,
    firepolicycomponentservice,
    OwnbranchMasterService,
    schemedropdownService,
    marketsharesomponentservice,
    stockcomponentservice,
    governmentsecuritycomponentservice,
    plantmachineryService,
    furnitureandfixtureservice,
    VehicleService,
    landandbuildingsService,
    goldandsilverService,
    customerinsuranceService,
    InsuranceMasterDropdownService,
    BookdebtsService,
    pleadgestockService
  ],
  declarations: [
    SecurityDetailsComponent,
    OtherSecurityComponent,
    FirePolicyComponent,
    MarketSharesComponent,
    StockStatementComponent,
    GovtSecurityAndLicComponent,
    PlantAndMachineryComponent,
    FurnitureAndFixtureComponent,
    VehicleComponent,
    LandAndBuildingsComponent,
    GoldAndSilverComponent,
    CustomerInsuranceComponent,
    BookDebtsComponent,
    PleadgeStockComponent,
    OwnDepositsComponent,
    OtherSecurity2Component,
  ],
})
export class SecurityDetailsModule {}
