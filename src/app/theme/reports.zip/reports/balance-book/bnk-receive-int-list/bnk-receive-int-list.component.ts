import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bnk-receive-int-list',
  templateUrl: './bnk-receive-int-list.component.html',
  styleUrls: ['./bnk-receive-int-list.component.scss']
})
export class BnkReceiveIntListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
