import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bnk-glconsist-repo',
  templateUrl: './bnk-glconsist-repo.component.html',
  styleUrls: ['./bnk-glconsist-repo.component.scss']
})
export class BnkGLConsistRepoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
