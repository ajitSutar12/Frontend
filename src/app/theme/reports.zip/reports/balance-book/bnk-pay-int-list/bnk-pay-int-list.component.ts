import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bnk-pay-int-list',
  templateUrl: './bnk-pay-int-list.component.html',
  styleUrls: ['./bnk-pay-int-list.component.scss']
})
export class BnkPayIntListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
