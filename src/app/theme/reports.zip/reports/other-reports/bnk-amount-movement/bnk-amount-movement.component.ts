import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bnk-amount-movement',
  templateUrl: './bnk-amount-movement.component.html',
  styleUrls: ['./bnk-amount-movement.component.scss']
})
export class BnkAmountMovementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
