import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayrollSettingsComponent } from './payroll-settings.component';

describe('PayrollSettingsComponent', () => {
  let component: PayrollSettingsComponent;
  let fixture: ComponentFixture<PayrollSettingsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayrollSettingsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayrollSettingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
