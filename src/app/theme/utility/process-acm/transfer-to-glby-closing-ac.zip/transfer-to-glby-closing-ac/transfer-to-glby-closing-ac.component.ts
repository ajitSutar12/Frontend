import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { NgSelectConfig } from '@ng-select/ng-select';
import { SchemeAccountNoService } from 'src/app/shared/dropdownService/schemeAccountNo.service';
import { OwnbranchMasterService } from 'src/app/shared/dropdownService/own-branch-master-dropdown.service';
import { SchemeCodeDropdownService } from 'src/app/shared/dropdownService/scheme-code-dropdown.service';
import { ACMasterDropdownService } from 'src/app/shared/dropdownService/ac-master-dropdown.service';
import Swal from 'sweetalert2';
@Component({
  selector: 'app-transfer-to-glby-closing-ac',
  templateUrl: './transfer-to-glby-closing-ac.component.html',
  styleUrls: ['./transfer-to-glby-closing-ac.component.scss']
})
export class TransferToGLbyClosingACComponent implements OnInit {

  // variable for validation
  formSubmitted = false;
  // Created Form Group
  angForm: FormGroup;

  // dropdown variables
  scheme
  ngscheme: any = null
  ngBranchCode: any = null
  glaccount: any = null;
  schemeACNo: any[];
  branch_code: any[];
  schemeedit: any;
  ACMasterDropdown: any[];

  totalCharges: any = null
  // Date variables
  todate: any = null;
  fromdate:any=null
  maxDate: Date;
  minDate: Date;

  // minDate = document.getElementById("FROM_DATE") as HTMLInputElement;
  // variables for button
  showButton: boolean =true;
  updateShow: boolean;
  newbtnShow: boolean;
  setdate: string;
  resettodate: string;
  constructor(
    private fb: FormBuilder,
    private config: NgSelectConfig,
    private ownbranchMasterService: OwnbranchMasterService,
    private schemeAccountNoService: SchemeAccountNoService,
    private schemeCodeDropdownService: SchemeCodeDropdownService,
    public ACMasterDropdownService: ACMasterDropdownService,
  ) {
    this.maxDate = new Date();
    this.minDate = new Date();
    this.minDate.setDate(this.minDate.getDate() - 1);
    this.maxDate.setDate(this.maxDate.getDate())
  }

  ngOnInit(): void {
    this.createForm()

    this.ownbranchMasterService.getOwnbranchList().pipe(first()).subscribe(data => {
      this.branch_code = data;
      this.ngBranchCode = data[0].value
    })
    this.schemeCodeDropdownService.getAllSchemeList1().pipe(first()).subscribe(data => {
      var allscheme = data.filter(function (scheme) {
        return (scheme.name == 'GS' || scheme.name == 'SH');
      });
      this.scheme = allscheme;
    })

  }
  getACmastercode(event){
    console.log(event)
   
    this.ACMasterDropdownService.getACMasterList().pipe(first()).subscribe(data => {
      this.ACMasterDropdown = data;
    })
  }
  // Method to handle validation of form
  createForm() {
    this.angForm = this.fb.group({
      BRANCH_CODE: ['', [Validators.required]],
      AC_TYPE: ['', [Validators.required]],
      FROM_DATE: ['', [Validators.required]],
      TO_DATE: ['', [Validators.required]],
      GL_AC: [''],
      TOTAL_CHARGES:[''],
      PARTICULAR:[''],
      TRAN_PASSING:[''],
    })
  }
  getBranch() {

    this.getIntroducer()
  }
  schemechange(event) {
    this.getschemename = event.name
    this.schemeedit = event.value
    this.getIntroducer()
  }
  obj: any
  getschemename: any
  //get account no according scheme for introducer
  getIntroducer() {
    this.obj = [this.schemeedit, this.ngBranchCode]
    switch (this.getschemename) {
   
      case 'SH':
        this.schemeAccountNoService.getShareSchemeList1(this.obj).pipe(first()).subscribe(data => {
          this.schemeACNo = data;
        })
        break;
      case 'GS':
        this.schemeAccountNoService.getAnamatSchemeList1(this.obj).pipe(first()).subscribe(data => {
          this.schemeACNo = data;
        })
        break
    }
  }
    //for checking dates
  //   checkdate(data: any) {
  //  debugger
  //     let fromdate = document.getElementById("FROM_DATE") as HTMLInputElement;
  //     console.log('From Date' +fromdate)
  //     let todate = document.getElementById("TO_DATE") as HTMLInputElement;
  //     console.log('To Date' +todate)
  //     this.setdate = fromdate.value;
  
  //     if (data != "") {
  //       if (this.setdate > data) {
  
  //         Swal.fire(
  //           "Cancelled",
  //           "From Date must be less than To date",
  //           "info"
  //         );
  
  //         this.resettodate = "";
  //       } else {
  
  //       }
  //     }
  //   }
    checkdate() {
      debugger
      // let minDate = document.getElementById("FROM_DATE") as HTMLInputElement;
      //     console.log('From Date' +minDate)
      if (this.angForm.controls['FROM_DATE'].value < this.angForm.controls['TO_DATE'].value){
           Swal.fire(
             "Cancelled",
             "From Date must be less than To date",
             "info"
           );
      }
    }


    

}
