import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-npamarking',
  templateUrl: './npamarking.component.html',
  styleUrls: ['./npamarking.component.scss']
})
export class NPAMarkingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
