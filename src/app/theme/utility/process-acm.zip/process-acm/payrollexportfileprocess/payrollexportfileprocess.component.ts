import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payrollexportfileprocess',
  templateUrl: './payrollexportfileprocess.component.html',
  styleUrls: ['./payrollexportfileprocess.component.scss']
})
export class PayrollexportfileprocessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
