import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dead-stock-depreciation',
  templateUrl: './dead-stock-depreciation.component.html',
  styleUrls: ['./dead-stock-depreciation.component.scss']
})
export class DeadStockDepreciationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
