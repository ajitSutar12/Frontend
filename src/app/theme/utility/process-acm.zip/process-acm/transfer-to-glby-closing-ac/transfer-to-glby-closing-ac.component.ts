import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-transfer-to-glby-closing-ac',
  templateUrl: './transfer-to-glby-closing-ac.component.html',
  styleUrls: ['./transfer-to-glby-closing-ac.component.scss']
})
export class TransferToGLbyClosingACComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
