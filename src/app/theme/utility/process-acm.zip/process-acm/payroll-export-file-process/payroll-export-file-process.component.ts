import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payroll-export-file-process',
  templateUrl: './payroll-export-file-process.component.html',
  styleUrls: ['./payroll-export-file-process.component.scss']
})
export class PayrollExportFileProcessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
