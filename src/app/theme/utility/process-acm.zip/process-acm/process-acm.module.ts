import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProcessACMComponent } from './process-acm.component';
import { ProcessACMRoutingModule } from './process-acm-routing.module';
import {SharedModule} from '../../../shared/shared.module';
import {DataTablesModule} from 'angular-datatables';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { UserAuthInterceptor } from 'src/app/user-auth.interceptor';
import { NPAProcessComponent } from './npaprocess/npaprocess.component';
import { NPAMarkingComponent } from './npamarking/npamarking.component';
import { NPAProcessLockingComponent } from './npaprocess-locking/npaprocess-locking.component';
import { DeadStockDepreciationComponent } from './dead-stock-depreciation/dead-stock-depreciation.component';
import { OverdraftInterestPostingComponent } from './overdraft-interest-posting/overdraft-interest-posting.component';
import { PenalInterestCalculationComponent } from './penal-interest-calculation/penal-interest-calculation.component';
import { TransferToGLbyClosingACComponent } from './transfer-to-glby-closing-ac/transfer-to-glby-closing-ac.component';
import { PayrolldatatransferComponent } from './payrolldatatransfer/payrolldatatransfer.component';
import { PayrollexportfileprocessComponent } from './payrollexportfileprocess/payrollexportfileprocess.component';


@NgModule({
  imports: [
    CommonModule,
    ProcessACMRoutingModule,
    SharedModule,
    DataTablesModule
  ],
  declarations: [
    ProcessACMComponent,
    NPAProcessComponent,
    NPAMarkingComponent,
    NPAProcessLockingComponent, 
    DeadStockDepreciationComponent, 
    OverdraftInterestPostingComponent, 
    PenalInterestCalculationComponent, 
    TransferToGLbyClosingACComponent,
    PayrolldatatransferComponent, 
    PayrollexportfileprocessComponent],
  providers:[{
    provide: HTTP_INTERCEPTORS,
    useClass: UserAuthInterceptor,
    multi: true
  },]
})
export class ProcessACMModule { }
