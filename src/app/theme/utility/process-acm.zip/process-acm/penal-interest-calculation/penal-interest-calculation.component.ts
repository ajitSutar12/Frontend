import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-penal-interest-calculation',
  templateUrl: './penal-interest-calculation.component.html',
  styleUrls: ['./penal-interest-calculation.component.scss']
})
export class PenalInterestCalculationComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
