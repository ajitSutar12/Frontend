import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-overdraft-interest-posting',
  templateUrl: './overdraft-interest-posting.component.html',
  styleUrls: ['./overdraft-interest-posting.component.scss']
})
export class OverdraftInterestPostingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
