import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payrolldatatransfer',
  templateUrl: './payrolldatatransfer.component.html',
  styleUrls: ['./payrolldatatransfer.component.scss']
})
export class PayrolldatatransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
