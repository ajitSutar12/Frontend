import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-npaprocess-locking',
  templateUrl: './npaprocess-locking.component.html',
  styleUrls: ['./npaprocess-locking.component.scss']
})
export class NPAProcessLockingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
