import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-npaprocess',
  templateUrl: './npaprocess.component.html',
  styleUrls: ['./npaprocess.component.scss']
})
export class NPAProcessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
