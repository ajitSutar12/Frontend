import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-final-reports',
  templateUrl: './final-reports.component.html',
  styleUrls: ['./final-reports.component.scss']
})
export class FinalReportsComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  
  }

}
