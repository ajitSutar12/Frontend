import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { first } from 'rxjs/operators';
import { SchemeCodeDropdownService } from 'src/app/shared/dropdownService/scheme-code-dropdown.service';
import { SchemeAccountNoService } from 'src/app/shared/dropdownService/schemeAccountNo.service';

@Component({
  selector: 'app-member-view',
  templateUrl: './member-view.component.html',
  styleUrls: ['./member-view.component.scss']
})
export class MemberViewComponent implements OnInit {
  angForm : FormGroup;
  obj: any[];
  scheme_code: any;
  ngIntroducer: any = null;
  schemeList:any[];
  constructor(
    private fb: FormBuilder,
    private _schemeService: SchemeAccountNoService,
    public schemeCodeDropdownService: SchemeCodeDropdownService,

  ) { }

  //ngfor variables
  introducerACNo


  //ngmodel variables
  selectedMemno

  ngOnInit(): void {
    
   this.createForm();

   let data: any = localStorage.getItem('user');
   let result = JSON.parse(data);
   let branchCode = result.branch.id;
   let code = 1;
   this.obj = [code,branchCode]

   this._schemeService.getShareSchemeList1(this.obj).subscribe(data => {
     console.log(data);
     
     this.introducerACNo = data;

   })
   this.schemeCodeDropdownService.getAllSchemeList1().pipe(first()).subscribe(data => {
     
    var filtered = data.filter(function (scheme) {
      return (scheme.name == 'TD' || scheme.name == 'PG' || scheme.name == 'LN' || scheme.name == 'CC' || scheme.name == 'SH' || scheme.name == 'GL' || scheme.name == 'CA'  || scheme.name == 'LK' || scheme.name == 'AG'  || scheme.name == 'IV'  || scheme.name == 'GS' || scheme.name == 'SB'  );
    });
    this.schemeList = filtered;
    this.ngIntroducer = null;
  })
  }
  View(){}
  printTextArea(){
    this.calculateTotalBalance();
    this.calculateTotalBalance1();
  }

  createForm(){
    this.angForm = this.fb.group({
      scheme_code: ["", [ Validators.required]],
      memNo: ['',[Validators.required]],
      empNo: ['',[Validators.required]],
      date: ['',[Validators.required]],
      Division : ['',[Validators.required]],
      Date_of_Birth: ['',[Validators.required]],
      Joiningdate :['',[Validators.required]],
      Retairmentdate:['',[Validators.required]],
      tlAmt:['',[Validators.required]],
      tdAmt:['',[Validators.required]],
      tioLoan:['',[Validators.required]],
      tioDep:['',[Validators.required]],
    });
  }

  tableData = [
    { accountNumber: 1, schemeName: 'abc', installment: 1200, balance: 30, interestAmount: 2 ,balance1:50 },
    { accountNumber: 2, schemeName: 'xyz', installment: 1200, balance: 20, interestAmount: 2, balance1:20 }
    // Add more rows as needed
  ];

  totalBalance: number;
  totalBalance1: number;

  calculateTotalBalance() {
    this.totalBalance = this.tableData.reduce((total, row) => total + row.balance, 0);
  }
  calculateTotalBalance1() {
    this.totalBalance1 = this.tableData.reduce((total, row) => total + row.balance1, 0);
  }

}
