import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import * as moment from 'moment';
import { SystemMasterParametersService } from '../../utility/scheme-parameters/system-master-parameters/system-master-parameters.service';

@Component({
  selector: 'app-locker-view',
  templateUrl: './locker-view.component.html',
  styleUrls: ['./locker-view.component.scss']
})
export class LockerViewComponent implements OnInit {
  maxDate: any;
  minDate: any;
  angForm: FormGroup;
  ngLockerSize
  lockerViewArray: any

  constructor(
    private fb: FormBuilder,
    private http: HttpClient, private systemParameter: SystemMasterParametersService,

  ) {
    this.systemParameter.getFormData(1).subscribe(data => {
      this.maxDate = moment(data.CURRENT_DATE, 'DD/MM/YYYY')
      this.maxDate = this.maxDate._d
      this.minDate = this.maxDate._d
    })
  }

  ngOnInit(): void {
    this.createForm()
    let sendData
    let obj = {
      "branch": sendData
    }

    this.http.post('http://192.168.1.121:3002/locker-master/lockersize', obj).subscribe((data) => {
      console.log(data, 'locker view')
      this.lockerViewArray = data
    });

  }

  createForm() {
    this.angForm = this.fb.group({
      LOCKER_SIZE: ['', [Validators.required,]],

    })
  }

  lockerData
  lockerBox
  lockerCount

  lockerView(sizeSrNo: string) {

    let userData = JSON.parse(localStorage.getItem('user'));
    let branch = userData.branch.id

    let obj = {
      'SIZE_SR_NO': sizeSrNo,
      'branch': branch
    }

    this.http.post('http://192.168.1.121:3002/locker-master/lockerdetails', obj).subscribe((data) => {

      this.lockerData = data
      this.lockerBox = data[0].LOCKER_TONO
      this.lockerCount = parseInt(this.lockerBox)

      console.log(this.lockerData, 'data')
    });
  }

  openModal() {
    // this.showMoadl = true
    const modalDiv = document.getElementById('myModal');
    if (modalDiv != null) {
      modalDiv.style.display = 'block'
    }
  }

  // showMoadl: boolean = false
  closeModal(): void {
    const modalDiv = document.getElementById('myModal');
    if (modalDiv != null) {
      modalDiv.style.display = 'none';
    }
  }
}
