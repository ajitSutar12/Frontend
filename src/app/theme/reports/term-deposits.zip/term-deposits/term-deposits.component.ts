import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-term-deposits',
  templateUrl: './term-deposits.component.html',
  styleUrls: ['./term-deposits.component.scss']
})
export class TermDepositsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
