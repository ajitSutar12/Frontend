import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bnk-other-bal-list',
  templateUrl: './bnk-other-bal-list.component.html',
  styleUrls: ['./bnk-other-bal-list.component.scss']
})
export class BnkOtherBalListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
