import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-denomination-reports',
  templateUrl: './denomination-reports.component.html',
  styleUrls: ['./denomination-reports.component.scss']
})
export class DenominationReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
