import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nottice',
  templateUrl: './nottice.component.html',
  styleUrls: ['./nottice.component.scss']
})
export class NotticeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
