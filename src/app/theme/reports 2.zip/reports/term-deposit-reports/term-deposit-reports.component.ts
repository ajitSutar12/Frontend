import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-term-deposit-reports',
  templateUrl: './term-deposit-reports.component.html',
  styleUrls: ['./term-deposit-reports.component.scss']
})
export class TermDepositReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
