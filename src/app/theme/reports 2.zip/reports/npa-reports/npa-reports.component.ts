import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-npa-reports',
  templateUrl: './npa-reports.component.html',
  styleUrls: ['./npa-reports.component.scss']
})
export class NpaReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
