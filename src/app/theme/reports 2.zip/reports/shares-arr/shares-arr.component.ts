import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shares-arr',
  templateUrl: './shares-arr.component.html',
  styleUrls: ['./shares-arr.component.scss']
})
export class SharesARRComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
