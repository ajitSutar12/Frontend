import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shares-adr',
  templateUrl: './shares-adr.component.html',
  styleUrls: ['./shares-adr.component.scss']
})
export class SharesADRComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
