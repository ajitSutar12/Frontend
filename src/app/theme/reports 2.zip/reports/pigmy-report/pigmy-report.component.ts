import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pigmy-report',
  templateUrl: './pigmy-report.component.html',
  styleUrls: ['./pigmy-report.component.scss']
})
export class PigmyReportComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
