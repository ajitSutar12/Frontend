// import { Injectable } from '@angular/core';
// import { Observable, throwError } from 'rxjs';
// import 'rxjs/Rx';
// // import { HttpClient } from '@angular/common/http';
// import { HttpClient, HttpHeaders, HttpRequest, HttpEvent } from '@angular/common/http';
// import { catchError, map } from 'rxjs/operators';
// import Swal from 'sweetalert2';
// import { environment } from '../../../../environments/environment';

// @Injectable({
//   providedIn: 'root'
// })
// export class StatementService {
//     // Variable for handleError
//     [x: string]: any;
//     // API 
//     url = environment.base_url;
//     constructor(private http: HttpClient) { }

//     // postRequest(url1: string, data: any): any {
//     //     let headers = new HttpHeaders({
//     //   'Content-Type': 'application/json',
//     //   'Accept': 'application/json',
//     // })
//     // let payload = data; 
//     // let endPoint =“api base url” + url1;
//     // return this.http.post(endPoint, payload, { headers });

//     //   }

// }
