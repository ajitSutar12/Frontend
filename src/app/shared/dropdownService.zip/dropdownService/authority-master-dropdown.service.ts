import { Injectable } from '@angular/core';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class AuthorityMasterDropdownService {

    url = "http://localhost:4000/authority-master";

    authorityMasterObject = new Array();

    constructor(private http: HttpClient) { }

    public getAuthorityMasterList() {
        return this.http.get<any>(this.url + '/')
            .pipe(map(ele => {
                ele.forEach(element => {
                    let obj = { label: element.NAME, value: element.id };
                    this.authorityMasterObject.push(obj)
                });
                return this.authorityMasterObject;
            }));
    }

}