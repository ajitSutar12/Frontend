import { MinusPipe } from './minus.pipe';

describe('MinusPipe', () => {
  it('create an instance', () => {
    const pipe = new MinusPipe();
    expect(pipe).toBeTruthy();
  });
});
