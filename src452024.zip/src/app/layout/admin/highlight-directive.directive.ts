// import { Directive } from '@angular/core';
import { Directive, ElementRef, Input, OnChanges } from '@angular/core';

@Directive({
  selector: '[appHighlightDirective]'
})
export class HighlightDirectiveDirective {

  @Input('appHighlightDirective') searchTerm: string;

  constructor(private el: ElementRef) {}

  // ngOnChanges(): void {
  //   if (this.searchTerm && this.searchTerm.length > 0) {
  //     this.highlight(this.searchTerm);
  //   } else {
  //     this.removeHighlight();
  //   }
  // }

  // private highlight(term: string): void {
  //   const innerHTML = this.el.nativeElement.innerHTML;
  //   const highlightedText = innerHTML.replace(new RegExp(term, 'gi'), match => `<span class="highlight">${match}</span>`);
  //   this.el.nativeElement.innerHTML = highlightedText;
  // }

  // private removeHighlight(): void {
  //   const innerHTML = this.el.nativeElement.innerHTML;
  //   this.el.nativeElement.innerHTML = innerHTML.replace(/<span class="highlight">(.*?)<\/span>/gi, '$1');
  // }
}
