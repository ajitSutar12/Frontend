import { EditDirective } from './edit.directive';

describe('EditDirective', () => {
  it('should create an instance', () => {
    const directive = new EditDirective();
    expect(directive).toBeTruthy();
  });
});
